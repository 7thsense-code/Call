package com.example.call;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.call.R;
import android.net.Uri;


public class MainActivity extends Activity {
    private EditText phoneNumberEditText;
    private Button callButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phoneNumberEditText = (EditText) findViewById(R.id.phone_number);
        callButton = (Button) findViewById(R.id.call_button);

        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = phoneNumberEditText.getText().toString();
                if (phoneNumber.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Please enter a phone number", Toast.LENGTH_SHORT).show();
                } else {
                    // Implement the logic to make a call when the button is clicked
                    // For now, just display a toast message indicating that a call is being initiated
                    Toast.makeText(getBaseContext(), "Calling...", Toast.LENGTH_SHORT).show();

                    // Add code to initiate the call here
                    // For example:
                    Intent intent = new Intent(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:" + phoneNumber));
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                    }
                }
            }
        });
    }
}
